﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using bianyuanjishuan.Model;
using Catel.MVVM;

namespace bianyuanjishuan.VIewModel
{
    public class MainviewModel
    {
        public UserModel UserInfo { get; set;}
        private FrameworkElement _mainContent;

        public FrameworkElement MainContent
        {
            get { return _mainContent; }
            set { _mainContent = value; }
        }
    }
}
