﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Threading.Tasks;

namespace bianyuanjishuan.VIewModel
{
   public class LoginViewModel
    {
        

        public LoginViewModel()
        {
            
        }
    }
}
