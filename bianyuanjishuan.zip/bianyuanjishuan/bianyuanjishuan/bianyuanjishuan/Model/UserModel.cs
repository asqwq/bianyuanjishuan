﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bianyuanjishuan.Model
{
    public class UserModel
    {
        private int _avatar;

        public int Avatar
        {
            get { return _avatar; }
            set { _avatar = value; }
        }

    }
}
