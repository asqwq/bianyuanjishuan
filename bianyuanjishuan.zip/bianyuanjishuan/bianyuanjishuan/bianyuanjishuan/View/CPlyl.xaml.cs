﻿using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bianyuanjishuan.View
{
    /// <summary>
    /// CPlyl.xaml 的交互逻辑
    /// </summary>
    public partial class CPlyl : UserControl
    {
        public SeriesCollection SeriesCollection { get; set; }
        public List<string> Labels { get; set; }
        private double _trend;
        private double[] temp = { 1, 3, 2, 4, -3, 5, 2, 1 };
        public CPlyl()
        {
            InitializeComponent();
            //实例化一条折线图
            LineSeries mylineseries = new LineSeries();
            //设置折线的标题
            mylineseries.Title = "磁盘利用率";
            //折线图直线形式
            mylineseries.LineSmoothness = 0;
            //折线图的无点样式
            mylineseries.PointGeometry = null;

            //添加横坐标
            Labels = new List<string> { "1", "3", "2", "4", "-3", "5", "2", "1" };
            //添加折线图的数据
            mylineseries.Values = new ChartValues<double>(temp);
            SeriesCollection = new SeriesCollection { };
            SeriesCollection.Add(mylineseries);
            _trend = 32;
            linestart();
            DataContext = this;
        }
        [DllImport("kernel32 ")]
        public static extern void GetWindowsDirectory(StringBuilder WinDir, int count);
        [DllImport("kernel32 ")]
        public static extern void GetSystemDirectory(StringBuilder SysDir, int count);
        [DllImport("kernel32 ")]
        public static extern void GlobalMemoryStatus(ref MEMORY_INFO meminfo);
        


        //定义内存的信息结构
        [StructLayout(LayoutKind.Sequential)]
        public struct MEMORY_INFO
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public uint dwTotalPhys;
            public uint dwAvailPhys;
            public uint dwTotalPageFile;
            public uint dwAvailPageFile;
            public uint dwTotalVirtual;
            public uint dwAvailVirtual;
        }
        //连续折线图的方法
        public void linestart()
        {

           

            Task.Run(() =>
            {
                
                var r = new Random();
                while (true)
                {
                    Thread.Sleep(300);
                    WqlObjectQuery wmiquery = new WqlObjectQuery("select * from Win64_LogiCalDisk");
                    ManagementObjectSearcher wmifind = new ManagementObjectSearcher(wmiquery);

                 

                    MEMORY_INFO MemInfo;
                    MemInfo = new MEMORY_INFO();
                    GlobalMemoryStatus(ref MemInfo);
                    string cpulyl = MemInfo.dwMemoryLoad.ToString();
                    _trend =Convert.ToInt32(cpulyl);
                    
                    //通过Dispatcher在工作线程中更新窗体的UI元素
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        //更新横坐标时间
                        Labels.Add(DateTime.Now.ToString());
                        Labels.RemoveAt(0);
                        //更新纵坐标数据
                        SeriesCollection[0].Values.Add(_trend);
                        SeriesCollection[0].Values.RemoveAt(0);
                    });
                }
            });
        }
    }
}