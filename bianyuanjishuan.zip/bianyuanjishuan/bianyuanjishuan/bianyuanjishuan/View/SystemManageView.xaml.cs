﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bianyuanjishuan.View
{
    /// <summary>
    /// SystemManageView.xaml 的交互逻辑
    /// </summary>
    public partial class SystemManageView : UserControl
    {
        private float angleNext = 0;
        private float angelCurrent = 0;
        public SystemManageView()
        {
            InitializeComponent();
            DrawScale();
        }

        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            RotateTransform rt = new RotateTransform();
            rt.CenterX = 200;
            rt.CenterY = 200;

            this.indicatorPin.RenderTransform = rt;

            angelCurrent = angleNext;
            Random random = new Random();
            angleNext = random.Next(5);




           double timeAnimation = Math.Abs(angelCurrent - angleNext) * 8;
            DoubleAnimation da = new DoubleAnimation(angelCurrent, angleNext, new Duration(TimeSpan.FromMilliseconds(timeAnimation)));
            da.AccelerationRatio = 1;
            rt.BeginAnimation(RotateTransform.AngleProperty, da);

            this.currentValueTxtBlock.Text = string.Format("当前网速值：{0}M", angleNext);
        }

        //获取物理网卡
        static string Bar()
        {
            var managementClass = new ManagementClass("Win32_NetworkAdapter");
            var managementObjectCollection = managementClass.GetInstances();
            var builder = new StringBuilder();
            foreach (var managementObject in managementObjectCollection.OfType<ManagementObject>())
            {
                using (managementObject)
                {
                    if (managementObject["NetConnectionStatus"] != null
                        && managementObject["NetConnectionStatus"].ToString() == "2"
                        && managementObject["PNPDeviceID"].ToString().Contains("PCI"))
                    {
                        if (managementObject["MacAddress"] == null)
                        {
                            continue;
                        }

                        builder.AppendLine(managementObject["MacAddress"].ToString().ToUpper());
                    }
                }
            }

            return builder.ToString();
        }

        //获取网速
        static float getws()
        {

            const int numberOfIterations = 10;
            PerformanceCounter bandwidthCounter = new PerformanceCounter("Network Interface", "Current Bandwidth", "B0:5C:DA:96:43:10");
            float bandwidth = bandwidthCounter.NextValue();//valor fixo 10Mb/100Mn/
            PerformanceCounter dataSentCounter = new PerformanceCounter("Network Interface", "Bytes Sent/sec", Bar());

            PerformanceCounter dataReceivedCounter = new PerformanceCounter("Network Interface", "Bytes Received/sec", "B0:5C:DA:96:43:10");
            float sendSum = 0;
            float receiveSum = 0;

            for (int index = 0; index < numberOfIterations; index++)
            {
                sendSum += dataSentCounter.NextValue();
                receiveSum += dataReceivedCounter.NextValue();
            }
            float dataSent = sendSum;
            float dataReceived = receiveSum;


            float utilization = (8 * (dataSent + dataReceived)) / (bandwidth * numberOfIterations) * 100;
            return utilization;
        }



        
        /// <summary>
        /// 画表盘的刻度
        /// </summary>
        private void DrawScale()
        {
            for (int i = 0; i <= 180; i += 5)
            {
                //添加刻度线
                Line lineScale = new Line();

                if (i % 10 == 0)
                {
                    lineScale.X1 = 200 - 160 * Math.Cos(i * Math.PI / 180);
                    lineScale.Y1 = 200 - 160 * Math.Sin(i * Math.PI / 180);
                    lineScale.Stroke = new SolidColorBrush(Color.FromRgb(0x00, 0xFF, 0));
                    lineScale.StrokeThickness = 3;

                    //添加刻度值
                    TextBlock txtScale = new TextBlock();
                    txtScale.Text = (i).ToString();
                    txtScale.FontSize = 10;
                    if (i <= 90)//对坐标值进行一定的修正
                    {
                        Canvas.SetLeft(txtScale, 200 - 155 * Math.Cos(i * Math.PI / 180));
                    }
                    else
                    {
                        Canvas.SetLeft(txtScale, 190 - 155 * Math.Cos(i * Math.PI / 180));
                    }
                    Canvas.SetTop(txtScale, 200 - 155 * Math.Sin(i * Math.PI / 180));
                    this.gaugeCanvas.Children.Add(txtScale);
                }
                else
                {
                    lineScale.X1 = 200 - 170 * Math.Cos(i * Math.PI / 180);
                    lineScale.Y1 = 200 - 170 * Math.Sin(i * Math.PI / 180);
                    lineScale.Stroke = new SolidColorBrush(Color.FromRgb(0xFF, 0x00, 0));
                    lineScale.StrokeThickness = 1;
                }

                lineScale.X2 = 200 - 180 * Math.Cos(i * Math.PI / 180);
                lineScale.Y2 = 200 - 180 * Math.Sin(i * Math.PI / 180);

                this.gaugeCanvas.Children.Add(lineScale);
            }
        }
    }
}