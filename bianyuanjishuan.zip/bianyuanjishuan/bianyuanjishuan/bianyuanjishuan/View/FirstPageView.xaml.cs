﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bianyuanjishuan.View
{
    /// <summary>
    /// FirstPageView.xaml 的交互逻辑
    /// </summary>
    public partial class FirstPageView : UserControl
    {
        public FirstPageView()
        {
            InitializeComponent();
            SystemManageView page1 = new SystemManageView();
            Page_Change1.Content = new Frame()
            {
                Content = page1
            };

            CPUwendu page3 = new CPUwendu();
            Page_Change3.Content = new Frame()
            {
                Content = page3
            };

            CPlyl page4 = new CPlyl();
            Page_Change4.Content = new Frame()
            {
                Content = page4
            };

            FQlyl page5 = new FQlyl();
            Page_Change5.Content = new Frame()
            {
                Content = page5
            };

            UesrTest page2 = new UesrTest();
            Page_Change2.Content = new Frame()
            {
                Content = page2
            };
            this.MaxHeight = SystemParameters.PrimaryScreenHeight;
        }
    }
}
