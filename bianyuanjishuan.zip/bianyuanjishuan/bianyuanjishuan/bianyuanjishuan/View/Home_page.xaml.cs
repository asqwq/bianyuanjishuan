﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace bianyuanjishuan.View
{
    /// <summary>
    /// Home_page.xaml 的交互逻辑
    /// </summary>
    public partial class Home_page : UserControl
    {
        private DispatcherTimer ShowTimer;
        public Home_page()
        {
            InitializeComponent();
            sys_info page1 = new sys_info();
            Page_Change.Content = new Frame()
            {
                Content = page1
            };
            ShowTime();
            ShowTimer = new System.Windows.Threading.DispatcherTimer();

            ShowTimer.Tick += new EventHandler(ShowCurTimer);//起个Timer一直获取当前时间

            ShowTimer.Interval = new TimeSpan(0, 0, 0, 1, 0);

            ShowTimer.Start();
        }
        public void ShowCurTimer(object sender, EventArgs e)

        {

            ShowTime();

        }

        //ShowTime方法

        private void ShowTime()
        {
            //获得年月日
            this.tbDateText.Text = DateTime.Now.ToString("yyyy/MM/dd");   //yyyy/MM/dd
            //获得时分秒
            this.tbTimeText.Text = DateTime.Now.ToString("HH:mm:ss");
        }



        private void mune_1(object sender, RoutedEventArgs e)
        {
            sys_info page1 = new sys_info();
            Page_Change.Content = new Frame()
            {
                Content = page1
            };
        }


        private void mune_2(object sender, RoutedEventArgs e)
        {
            sys_2 page1 = new sys_2();
            Page_Change.Content = new Frame()
            {
                Content = page1
            };
        }

        private void mune_3(object sender, RoutedEventArgs e)
        {
            sys_3 page1 = new sys_3();
            Page_Change.Content = new Frame()
            {
                Content = page1
            };
        }
        private void mune_4(object sender, RoutedEventArgs e)
        {
            sys_4 page1 = new sys_4();
            Page_Change.Content = new Frame()
            {
                Content = page1
            };
        }

        private void mune_5(object sender, RoutedEventArgs e)
        {
            sys_5 page1 = new sys_5();
            Page_Change.Content = new Frame()
            {
                Content = page1
            };
        }
    }
}
